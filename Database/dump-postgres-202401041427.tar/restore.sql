--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Italian_Italy.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: aste_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.aste_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.aste_id OWNER TO postgres;

--
-- Name: images_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.images_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.images_id OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: immagini; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.immagini (
    id_prodotto character varying NOT NULL,
    img text,
    id integer NOT NULL
);


ALTER TABLE public.immagini OWNER TO postgres;

--
-- Name: immobili_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.immobili_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.immobili_id OWNER TO postgres;

--
-- Name: prodotti; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.prodotti (
    id character varying NOT NULL,
    nome character varying,
    venditore character varying,
    descrizione character varying,
    categoria character varying,
    prezzo double precision,
    numerovenduti integer
);


ALTER TABLE public.prodotti OWNER TO postgres;

--
-- Name: recensioni_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recensioni_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recensioni_id OWNER TO postgres;

--
-- Name: utenti; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.utenti (
    cf character varying NOT NULL,
    nome character varying,
    cognome character varying,
    email character varying,
    telefono bigint,
    tipologia character varying,
    password character varying
);


ALTER TABLE public.utenti OWNER TO postgres;

--
-- Data for Name: immagini; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4856.dat

--
-- Data for Name: prodotti; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4854.dat

--
-- Data for Name: utenti; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4855.dat

--
-- Name: aste_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.aste_id', 31, true);


--
-- Name: images_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.images_id', 25, true);


--
-- Name: immobili_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.immobili_id', 27, true);


--
-- Name: recensioni_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recensioni_id', 2, true);


--
-- Name: immagini immagini_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.immagini
    ADD CONSTRAINT immagini_pk PRIMARY KEY (id);


--
-- Name: prodotti prodotti_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.prodotti
    ADD CONSTRAINT prodotti_pk PRIMARY KEY (id);


--
-- Name: utenti utenti_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utenti
    ADD CONSTRAINT utenti_pk PRIMARY KEY (cf);


--
-- Name: immagini immagini_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.immagini
    ADD CONSTRAINT immagini_fk FOREIGN KEY (id_prodotto) REFERENCES public.prodotti(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

